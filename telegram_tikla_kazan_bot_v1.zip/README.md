# Telegram Tikla-Kazan Botu — İlk Sürüm

Bu sürüm:
- OYNA ile puan verir
- Bakiye ve yaklaşık TL/USDT karşılığı gösterir
- Günlük ödül verir
- Referans sistemi içerir
- Liderlik tablosu içerir
- TL/USDT çekim talebi oluşturur
- Admin'e yeni çekim bildirir
- Admin istatistikleri ve bekleyen çekimleri gösterir
- SQLite kullanır

## Replit kurulumu

1. Yeni bir Python Repl oluştur.
2. `bot.py` ve `requirements.txt` dosyalarını yükle.
3. Replit Secrets bölümünde:
   - `BOT_TOKEN` = BotFather'dan aldığın token
   - `ADMIN_ID` = kendi Telegram kullanıcı ID'n
   - `POINTS_PER_TL` = örn. `1000`
   - `USDT_RATE` = örn. `0.025` (1 TL'nin kaç USDT kabul edileceği; bunu kendin belirle)
4. Run komutunu `python bot.py` yap.
5. Telegram'da botuna `/start` gönder.

## Önemli
Bu bot otomatik olarak gerçek TL veya USDT ödeme yapmaz. Çekim talebi oluşturur ve admin'e bildirir. Gerçek ödeme için ayrıca güvenli bir ödeme/kripto altyapısı ve doğrulama gerekir.

Bot tokenini sohbetlerde paylaşma.
